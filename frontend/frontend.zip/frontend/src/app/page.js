"use client"
import { redirect } from 'next/navigation'
import React from 'react'

function page() {
  return redirect('/chat')
}

export default page
